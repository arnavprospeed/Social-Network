<?php
function redirect($location){
header("Location: ". $location);
} ?>
<html>
<head>
  <title>
    Social Network
  </title>
  <link rel="stylesheet" href="css/style.css">
  <script src="js/script.js"></script>
</head>

<body>
  <header>
    <div class="header">
      SOCIAL NETWORK: CONNECT WITH PEOPLE
    </div>
  </header>
