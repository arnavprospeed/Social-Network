<footer>
  <div id="footer-div">
    <p>Copyright &copyright 2015 Connect</p>
  </div>
</footer>
</body>
</html>
<?php
mysqli_close($connection);
?>
